
module.exports = { 
    secret: process.env.JWT_SECRET,
    // secret_client: process.env.JWT_SECRET_CLIENT,
    ttl: '168h'
}